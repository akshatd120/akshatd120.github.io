To Build the Project run "build-dynamic-linking.bat"

[NOTE: The project libraries are linked dynamically & Will only work if you have "mingw" installed]


The built app will be situated inside the folder "output"